from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
import sqlite3
from datetime import datetime
import json
from functools import wraps
import statistics  # Para calcular mediana
import pandas as pd  # Adicionado para exportação Excel
import io  # Adicionado para manipulação de arquivos
from fpdf import FPDF  # Adicionado para exportação PDF

app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = 'segunda_de_lei_secret_key_2023'

# O resto do seu código permanece o mesmo...

# Configuração do banco de dados
def get_db_connection():
    conn = sqlite3.connect('data/database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Inicialização do banco de dados
def init_db():
    conn = get_db_connection()
    
    # Tabela de jogadores
    conn.execute('''
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            total_points INTEGER DEFAULT 0,
            goals INTEGER DEFAULT 0,
            assists INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            draws INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            attendance INTEGER DEFAULT 0,
            delays INTEGER DEFAULT 0,
            absences INTEGER DEFAULT 0
        )
    ''')
    
    # Tabela de semanas
    conn.execute('''
        CREATE TABLE IF NOT EXISTS weeks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL UNIQUE,
            num_teams INTEGER NOT NULL
        )
    ''')
    
    # Tabela de times
    conn.execute('''
        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            week_id INTEGER NOT NULL,
            color TEXT NOT NULL,
            points INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            draws INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            goals_for INTEGER DEFAULT 0,
            goals_against INTEGER DEFAULT 0,
            FOREIGN KEY (week_id) REFERENCES weeks (id)
        )
    ''')
    
    # Tabela de jogadores por time
    conn.execute('''
        CREATE TABLE IF NOT EXISTS team_players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            team_id INTEGER NOT NULL,
            player_id INTEGER,
            avulso_name TEXT,
            goals INTEGER DEFAULT 0,
            assists INTEGER DEFAULT 0,
            attendance INTEGER DEFAULT 1,
            delay INTEGER DEFAULT 0,
            absence INTEGER DEFAULT 0,
            FOREIGN KEY (team_id) REFERENCES teams (id),
            FOREIGN KEY (player_id) REFERENCES players (id)
        )
    ''')
    
    # Tabela de partidas
    conn.execute('''
        CREATE TABLE IF NOT EXISTS matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            week_id INTEGER NOT NULL,
            team1_id INTEGER NOT NULL,
            team2_id INTEGER NOT NULL,
            goals_team1 INTEGER DEFAULT 0,
            goals_team2 INTEGER DEFAULT 0,
            FOREIGN KEY (week_id) REFERENCES weeks (id),
            FOREIGN KEY (team1_id) REFERENCES teams (id),
            FOREIGN KEY (team2_id) REFERENCES teams (id)
        )
    ''')
    
    conn.commit()
    conn.close()

# Inicializar jogadores e dados atuais da planilha
def init_players():
    conn = get_db_connection()
    players_data = [
        {"name": "MARLON", "total_points": 599, "goals": 40, "assists": 28, "wins": 64, "draws": 25, "losses": 51},
        {"name": "JONAS", "total_points": 584, "goals": 83, "assists": 25, "wins": 60, "draws": 25, "losses": 57},
        {"name": "LELO", "total_points": 578, "goals": 60, "assists": 43, "wins": 62, "draws": 24, "losses": 48},
        {"name": "PALMEIRAS", "total_points": 523, "goals": 49, "assists": 23, "wins": 54, "draws": 23, "losses": 63},
        {"name": "WESLEY", "total_points": 521, "goals": 31, "assists": 36, "wins": 53, "draws": 20, "losses": 53},
        {"name": "GUI", "total_points": 520, "goals": 58, "assists": 13, "wins": 62, "draws": 26, "losses": 44},
        {"name": "CHICO", "total_points": 514, "goals": 86, "assists": 36, "wins": 51, "draws": 26, "losses": 69},
        {"name": "CARVALHO", "total_points": 513, "goals": 31, "assists": 15, "wins": 59, "draws": 16, "losses": 47},
        {"name": "SIDAO", "total_points": 512, "goals": 51, "assists": 21, "wins": 62, "draws": 19, "losses": 45},
        {"name": "DUZAO", "total_points": 503, "goals": 13, "assists": 24, "wins": 58, "draws": 21, "losses": 43},
        {"name": "NANTES", "total_points": 500, "goals": 35, "assists": 23, "wins": 55, "draws": 28, "losses": 49},
        {"name": "RAPHA", "total_points": 496, "goals": 85, "assists": 36, "wins": 55, "draws": 21, "losses": 60},
        {"name": "MATHEUS", "total_points": 470, "goals": 2, "assists": 1, "wins": 52, "draws": 20, "losses": 46},
        {"name": "DODOY", "total_points": 453, "goals": 62, "assists": 25, "wins": 55, "draws": 18, "losses": 45},
        {"name": "LEO", "total_points": 422, "goals": 29, "assists": 8, "wins": 48, "draws": 26, "losses": 46},
        {"name": "LIMA", "total_points": 386, "goals": 44, "assists": 46, "wins": 37, "draws": 23, "losses": 50},
        {"name": "DOUGLAS", "total_points": 373, "goals": 20, "assists": 18, "wins": 37, "draws": 21, "losses": 40},
        {"name": "GIGA", "total_points": 337, "goals": 61, "assists": 23, "wins": 45, "draws": 21, "losses": 62},
        {"name": "ROBERTO", "total_points": 330, "goals": 0, "assists": 0, "wins": 33, "draws": 18, "losses": 35},
        {"name": "FELIXO", "total_points": 262, "goals": 30, "assists": 5, "wins": 35, "draws": 20, "losses": 51},
        {"name": "LUCAS", "total_points": 185, "goals": 18, "assists": 14, "wins": 23, "draws": 11, "losses": 22},
        {"name": "PASTORE", "total_points": 97, "goals": 0, "assists": 0, "wins": 12, "draws": 5, "losses": 5},
        {"name": "LUIZ", "total_points": 71, "goals": 5, "assists": 5, "wins": 9, "draws": 3, "losses": 4},
        {"name": "GOLEIRO", "total_points": 0, "goals": 0, "assists": 0, "wins": 0, "draws": 0, "losses": 0}
    ]
    
    for data in players_data:
        name = data["name"]
        try:
            conn.execute('INSERT INTO players (name) VALUES (?)', (name,))
        except sqlite3.IntegrityError:
            pass  # Já existe
        # Atualizar dados
        conn.execute('''
            UPDATE players SET total_points = ?, goals = ?, assists = ?, wins = ?, draws = ?, losses = ?
            WHERE name = ?
        ''', (data["total_points"], data["goals"], data["assists"], data["wins"], data["draws"], data["losses"], name))
    
    conn.commit()
    conn.close()

# Rotas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ranking')
def ranking():
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players ORDER BY total_points DESC').fetchall()
    
    # Última semana para pontos do último jogo
    last_week = conn.execute('SELECT * FROM weeks ORDER BY date DESC LIMIT 1').fetchone()
    last_teams = []
    if last_week:
        last_teams = conn.execute('SELECT color, points FROM teams WHERE week_id = ? ORDER BY points DESC', (last_week['id'],)).fetchall()
    
    conn.close()
    
    players_data = []
    total_games_list = []
    for player in players:
        total_games = player['wins'] + player['draws'] + player['losses']
        aproveitamento = ((player['wins'] * 3 + player['draws']) / (total_games * 3)) * 100 if total_games > 0 else 0
        players_data.append({
            'id': player['id'],
            'name': player['name'],
            'total_points': player['total_points'],
            'goals': player['goals'],
            'assists': player['assists'],
            'wins': player['wins'],
            'draws': player['draws'],
            'losses': player['losses'],
            'aproveitamento': round(aproveitamento, 2),
            'total_games': total_games
        })
        if total_games > 0:
            total_games_list.append(total_games)
    
    # Calcular mediana de jogos para filtro proporcional
    median_games = statistics.median(total_games_list) if total_games_list else 0
    
    # Filtrar jogadores com total_games >= mediana e encontrar max aproveitamento entre eles
    filtered_players = [p for p in players_data if p['total_games'] >= median_games]
    max_aproveitamento = max((p['aproveitamento'] for p in filtered_players), default=0)
    
    artilheiros = sorted(players_data, key=lambda x: x['goals'], reverse=True)[:10]
    assistencias = sorted(players_data, key=lambda x: x['assists'], reverse=True)[:10]
    
    return render_template('ranking.html', 
                           players=players_data, 
                           artilheiros=artilheiros, 
                           assistencias=assistencias,
                           last_teams=last_teams,
                           max_aproveitamento=max_aproveitamento)

@app.route('/export_ranking_excel')
def export_ranking_excel():
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players ORDER BY total_points DESC').fetchall()
    conn.close()
    
    data = []
    for player in players:
        total_games = player['wins'] + player['draws'] + player['losses']
        aproveitamento = ((player['wins'] * 3 + player['draws']) / (total_games * 3)) * 100 if total_games > 0 else 0
        data.append({
            'Nome': player['name'],
            'Pontos': player['total_points'],
            'Gols': player['goals'],
            'Assistências': player['assists'],
            'Vitórias': player['wins'],
            'Empates': player['draws'],
            'Derrotas': player['losses'],
            'Aproveitamento (%)': round(aproveitamento, 2)
        })
    
    df = pd.DataFrame(data)
    output = io.BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', download_name='classificacao.xlsx', as_attachment=True)

@app.route('/export_ranking_pdf')
def export_ranking_pdf():
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players ORDER BY total_points DESC').fetchall()
    conn.close()
    
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    
    pdf.cell(200, 10, txt="Classificação Geral", ln=1, align='C')
    
    # Cabeçalho da tabela
    pdf.cell(40, 10, 'Nome', border=1)
    pdf.cell(30, 10, 'Pontos', border=1)
    pdf.cell(20, 10, 'Gols', border=1)
    pdf.cell(30, 10, 'Assistências', border=1)
    pdf.cell(30, 10, 'Vitórias', border=1)
    pdf.cell(30, 10, 'Empates', border=1)
    pdf.cell(30, 10, 'Derrotas', border=1)
    pdf.cell(40, 10, 'Aproveitamento (%)', border=1, ln=1)
    
    for player in players:
        total_games = player['wins'] + player['draws'] + player['losses']
        aproveitamento = ((player['wins'] * 3 + player['draws']) / (total_games * 3)) * 100 if total_games > 0 else 0
        
        pdf.cell(40, 10, player['name'], border=1)
        pdf.cell(30, 10, str(player['total_points']), border=1)
        pdf.cell(20, 10, str(player['goals']), border=1)
        pdf.cell(30, 10, str(player['assists']), border=1)
        pdf.cell(30, 10, str(player['wins']), border=1)
        pdf.cell(30, 10, str(player['draws']), border=1)
        pdf.cell(30, 10, str(player['losses']), border=1)
        pdf.cell(40, 10, str(round(aproveitamento, 2)), border=1, ln=1)
    
    # Salvar em um arquivo temporário
    import tempfile
    import os
    
    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
        pdf.output(tmp_file.name)
        tmp_file.flush()
        
        # Ler o conteúdo do arquivo temporário
        with open(tmp_file.name, 'rb') as f:
            pdf_data = f.read()
        
        # Limpar o arquivo temporário
        os.unlink(tmp_file.name)
    
    # Criar resposta com os dados do PDF
    from flask import Response
    response = Response(pdf_data, mimetype='application/pdf')
    response.headers['Content-Disposition'] = 'attachment; filename=classificacao.pdf'
    
    return response
@app.route('/history')
def history():
    conn = get_db_connection()
    weeks = conn.execute('SELECT * FROM weeks ORDER BY date DESC').fetchall()
    conn.close()
    return render_template('history.html', weeks=weeks)

@app.route('/week_details/<int:week_id>')
def week_details(week_id):
    conn = get_db_connection()
    week = conn.execute('SELECT * FROM weeks WHERE id = ?', (week_id,)).fetchone()
    teams = conn.execute('SELECT * FROM teams WHERE week_id = ? ORDER BY points DESC', (week_id,)).fetchall()
    matches = conn.execute('SELECT * FROM matches WHERE week_id = ?', (week_id,)).fetchall()
    
    team_players = {}
    for team in teams:
        players = conn.execute('SELECT tp.*, p.name AS player_name FROM team_players tp LEFT JOIN players p ON tp.player_id = p.id WHERE tp.team_id = ?', (team['id'],)).fetchall()
        team_players[team['id']] = players
    
    team_names = {team['id']: team['color'] for team in teams}
    
    conn.close()
    return render_template('week_details.html', week=week, teams=teams, matches=matches, team_players=team_players, team_names=team_names)

@app.route('/manage_players', methods=['GET', 'POST'])
def manage_players():
    if request.method == 'POST':
        name = request.form['name'].upper()
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO players (name) VALUES (?)', (name,))
            conn.commit()
            flash('Jogador cadastrado com sucesso!', 'success')
        except sqlite3.IntegrityError:
            flash('Jogador já existe!', 'error')
        conn.close()
        return redirect(url_for('manage_players'))
    
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players ORDER BY name').fetchall()
    conn.close()
    return render_template('manage_players.html', players=players)

@app.route('/delete_player/<int:player_id>')
def delete_player(player_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM players WHERE id = ?', (player_id,))
    conn.commit()
    conn.close()
    flash('Jogador excluído com sucesso!', 'success')
    return redirect(url_for('manage_players'))

@app.route('/update_week', methods=['GET', 'POST'])
def update_week():
    if request.method == 'POST':
        date_str = request.form['date']
        num_teams = int(request.form['num_teams'])
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO weeks (date, num_teams) VALUES (?, ?)', (date_str, num_teams))
            week_id = cursor.lastrowid
            
            colors = ['Azul', 'Amarelo', 'Vermelho'] if num_teams == 3 else ['Azul', 'Amarelo', 'Preto', 'Vermelho']
            team_ids = {}
            for color in colors:
                cursor.execute('INSERT INTO teams (week_id, color) VALUES (?, ?)', (week_id, color))
                team_ids[color] = cursor.lastrowid
            
            for color in colors:
                team_id = team_ids[color]
                color_lower = color.lower()
                
                reg_ids = request.form.getlist(f'team_{color_lower}_reg_player_ids[]')
                reg_goals = request.form.getlist(f'team_{color_lower}_reg_goals[]')
                reg_assists = request.form.getlist(f'team_{color_lower}_reg_assists[]')
                reg_delays = request.form.getlist(f'team_{color_lower}_reg_delays[]')
                reg_absences = request.form.getlist(f'team_{color_lower}_reg_absences[]')
                
                for i in range(len(reg_ids)):
                    player_id = int(reg_ids[i]) if reg_ids[i] else None
                    goals = int(reg_goals[i]) if reg_goals[i] else 0
                    assists = int(reg_assists[i]) if reg_assists[i] else 0
                    delay = 1 if str(i) in reg_delays else 0
                    absence = 1 if str(i) in reg_absences else 0
                    attendance = 0 if absence else 1
                    cursor.execute('''
                        INSERT INTO team_players (team_id, player_id, goals, assists, attendance, delay, absence)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (team_id, player_id, goals, assists, attendance, delay, absence))
                
                av_names = request.form.getlist(f'team_{color_lower}_avulso_names[]')
                av_goals = request.form.getlist(f'team_{color_lower}_avulso_goals[]')
                av_assists = request.form.getlist(f'team_{color_lower}_avulso_assists[]')
                av_delays = request.form.getlist(f'team_{color_lower}_avulso_delays[]')
                av_absences = request.form.getlist(f'team_{color_lower}_avulso_absences[]')
                
                for i in range(len(av_names)):
                    name = av_names[i]
                    goals = int(av_goals[i]) if av_goals[i] else 0
                    assists = int(av_assists[i]) if av_assists[i] else 0
                    delay = 1 if str(i) in av_delays else 0
                    absence = 1 if str(i) in av_absences else 0
                    attendance = 0 if absence else 1
                    cursor.execute('''
                        INSERT INTO team_players (team_id, avulso_name, goals, assists, attendance, delay, absence)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (team_id, name, goals, assists, attendance, delay, absence))
            
            if num_teams == 3:
                matches_order = [
                    ('Azul', 'Amarelo'),
                    ('Azul', 'Vermelho'),
                    ('Amarelo', 'Vermelho'),
                    ('Amarelo', 'Azul'),
                    ('Vermelho', 'Azul'),
                    ('Vermelho', 'Amarelo'),
                    ('Azul', 'Amarelo'),
                    ('Vermelho', 'Azul'),
                    ('Amarelo', 'Vermelho')
                ]
            else:
                matches_order = [
                    ('Azul', 'Amarelo'),
                    ('Preto', 'Azul'),
                    ('Vermelho', 'Preto'),
                    ('Amarelo', 'Vermelho'),
                    ('Azul', 'Amarelo'),
                    ('Preto', 'Vermelho'),
                    ('Amarelo', 'Preto'),
                    ('Vermelho', 'Azul')
                ]
            
            for i, (team1, team2) in enumerate(matches_order):
                goals1 = int(request.form.get(f'match_{i}_goals_team1', 0))
                goals2 = int(request.form.get(f'match_{i}_goals_team2', 0))
                team1_id = team_ids[team1]
                team2_id = team_ids[team2]
                cursor.execute('''
                    INSERT INTO matches (week_id, team1_id, team2_id, goals_team1, goals_team2)
                    VALUES (?, ?, ?, ?, ?)
                ''', (week_id, team1_id, team2_id, goals1, goals2))
            
            for match in cursor.execute('SELECT * FROM matches WHERE week_id = ?', (week_id,)).fetchall():
                goals1 = match['goals_team1']
                goals2 = match['goals_team2']
                team1_id = match['team1_id']
                team2_id = match['team2_id']
                
                cursor.execute('UPDATE teams SET goals_for = goals_for + ?, goals_against = goals_against + ? WHERE id = ?', (goals1, goals2, team1_id))
                cursor.execute('UPDATE teams SET goals_for = goals_for + ?, goals_against = goals_against + ? WHERE id = ?', (goals2, goals1, team2_id))
                
                if goals1 > goals2:
                    cursor.execute('UPDATE teams SET wins = wins + 1 WHERE id = ?', (team1_id,))
                    cursor.execute('UPDATE teams SET losses = losses + 1 WHERE id = ?', (team2_id,))
                elif goals2 > goals1:
                    cursor.execute('UPDATE teams SET wins = wins + 1 WHERE id = ?', (team2_id,))
                    cursor.execute('UPDATE teams SET losses = losses + 1 WHERE id = ?', (team1_id,))
                else:
                    cursor.execute('UPDATE teams SET draws = draws + 1 WHERE id = ? OR id = ?', (team1_id, team2_id))
            
            for team in cursor.execute('SELECT * FROM teams WHERE week_id = ?', (week_id,)).fetchall():
                points = team['wins'] + team['draws'] + team['goals_for']
                cursor.execute('UPDATE teams SET points = ? WHERE id = ?', (points, team['id']))
            
            for team in cursor.execute('SELECT * FROM teams WHERE week_id = ?', (week_id,)).fetchall():
                team_id = team['id']
                team_wins = team['wins']
                team_draws = team['draws']
                team_losses = team['losses']
                
                for tp in cursor.execute('SELECT * FROM team_players WHERE team_id = ?', (team_id,)).fetchall():
                    if tp['player_id']:  # Apenas cadastrados
                        player_id = tp['player_id']
                        his_goals = tp['goals']
                        his_assists = tp['assists']
                        absence = tp['absence']
                        delay = tp['delay']
                        attendance = tp['attendance']
                        
                        point_delta = 0
                        if absence:
                            point_delta += -10
                            cursor.execute('UPDATE players SET absences = absences + 1 WHERE id = ?', (player_id,))
                        else:
                            point_delta += 3  # presença
                            cursor.execute('UPDATE players SET attendance = attendance + 1 WHERE id = ?', (player_id,))
                            if delay:
                                point_delta += -5
                                cursor.execute('UPDATE players SET delays = delays + 1 WHERE id = ?', (player_id,))
                            # Pontos do time e gols
                            point_delta += team_wins * 3 + team_draws * 1 + his_goals * 1
                            cursor.execute('UPDATE players SET wins = wins + ?, draws = draws + ?, losses = losses + ? WHERE id = ?', 
                                           (team_wins, team_draws, team_losses, player_id))
                        
                        cursor.execute('UPDATE players SET total_points = total_points + ?, goals = goals + ?, assists = assists + ? WHERE id = ?', 
                                       (point_delta, his_goals, his_assists, player_id))
            
            conn.commit()
            flash('Dados da semana atualizados com sucesso!', 'success')
            return redirect(url_for('results', week_id=week_id))
        except Exception as e:
            conn.rollback()
            flash(f'Erro ao atualizar dados: {str(e)}', 'error')
        finally:
            conn.close()
        
        return redirect(url_for('update_week'))
    
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players ORDER BY name').fetchall()
    conn.close()
    
    return render_template('update_week.html', players=players)

@app.route('/results/<int:week_id>')
def results(week_id):
    conn = get_db_connection()
    week = conn.execute('SELECT * FROM weeks WHERE id = ?', (week_id,)).fetchone()
    teams = conn.execute('SELECT * FROM teams WHERE week_id = ? ORDER BY points DESC', (week_id,)).fetchall()
    conn.close()
    return render_template('results.html', week=week, teams=teams)

@app.route('/get_players')
def get_players():
    conn = get_db_connection()
    players = conn.execute('SELECT id, name FROM players ORDER BY name').fetchall()
    conn.close()
    players_list = [{'id': p['id'], 'name': p['name']} for p in players]
    return jsonify(players_list)

if __name__ == '__main__':
    init_db()
    init_players()
    app.run(debug=True, host='0.0.0.0', port=5000)